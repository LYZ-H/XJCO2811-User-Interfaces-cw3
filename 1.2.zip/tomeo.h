#ifndef TOMEO_H
#define TOMEO_H

private slots:
void thumbMatch(vector<TheButtonInfo> out, QString f)

#endif // TOMEO_H
